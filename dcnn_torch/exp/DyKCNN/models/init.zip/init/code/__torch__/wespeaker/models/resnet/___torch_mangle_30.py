class SBSA(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  ln_q : __torch__.torch.nn.modules.conv.___torch_mangle_7.Conv2d
  ln_k : __torch__.torch.nn.modules.conv.___torch_mangle_7.Conv2d
  ln_v : __torch__.torch.nn.modules.conv.___torch_mangle_7.Conv2d
  def forward(self: __torch__.wespeaker.models.resnet.___torch_mangle_30.SBSA,
    x: Tensor) -> Tensor:
    n_batch = torch.size(x, 0)
    n_planes = torch.size(x, 1)
    n_freq = torch.size(x, 2)
    n_frame = torch.size(x, 3)
    ln_q = self.ln_q
    _0 = torch.permute((ln_q).forward(x, ), [0, 3, 2, 1])
    _1 = torch.contiguous(_0)
    _2 = [n_batch, n_frame, torch.mul(n_freq, n_planes)]
    q = torch.view(_1, _2)
    ln_k = self.ln_k
    _3 = torch.permute((ln_k).forward(x, ), [0, 3, 2, 1])
    _4 = torch.contiguous(_3)
    _5 = [n_batch, n_frame, torch.mul(n_freq, n_planes)]
    k = torch.view(_4, _5)
    ln_v = self.ln_v
    _6 = torch.permute((ln_v).forward(x, ), [0, 3, 2, 1])
    _7 = torch.contiguous(_6)
    _8 = [n_batch, n_frame, torch.mul(n_freq, n_planes)]
    v = torch.view(_7, _8)
    _9 = torch.matmul(q, torch.transpose(k, -2, -1))
    _10 = torch.sqrt(torch.mul(n_freq, n_planes))
    scores = torch.div(_9, _10)
    attn = torch.softmax(scores, -1)
    _11 = torch.matmul(attn, v)
    _12 = [n_batch, n_frame, n_freq, n_planes]
    _13 = torch.permute(torch.view(_11, _12), [0, 3, 2, 1])
    return torch.contiguous(_13)
