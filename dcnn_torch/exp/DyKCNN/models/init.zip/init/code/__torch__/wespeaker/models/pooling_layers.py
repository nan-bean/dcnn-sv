class TSTP(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  in_dim : int
  out_dim : int
  def forward(self: __torch__.wespeaker.models.pooling_layers.TSTP,
    x: Tensor) -> Tensor:
    pooling_mean = torch.mean(x, [-1])
    _0 = torch.add(torch.var(x, [-1]), 9.9999999999999995e-08)
    pooling_std = torch.sqrt(_0)
    pooling_mean0 = torch.flatten(pooling_mean, 1)
    pooling_std0 = torch.flatten(pooling_std, 1)
    stats = torch.cat([pooling_mean0, pooling_std0], 1)
    return stats
