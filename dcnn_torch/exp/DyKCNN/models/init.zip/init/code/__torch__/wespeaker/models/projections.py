class ArcMarginProduct(Module):
  __parameters__ = ["weight", ]
  __buffers__ = []
  weight : Tensor
  training : bool
  _is_full_backward_hook : Optional[bool]
  in_features : int
  out_features : int
  scale : float
  margin : float
  easy_margin : bool
  cos_m : float
  sin_m : float
  th : float
  mm : float
  mmm : float
  m : float
  def forward(self: __torch__.wespeaker.models.projections.ArcMarginProduct,
    input: Tensor,
    label: Tensor) -> Tensor:
    _0 = __torch__.torch.nn.functional.normalize
    _1 = _0(input, 2., 1, 9.9999999999999998e-13, None, )
    weight = self.weight
    _2 = _0(weight, 2., 1, 9.9999999999999998e-13, None, )
    cosine = torch.linear(_1, _2)
    _3 = torch.add(torch.neg(torch.pow(cosine, 2)), 1.)
    sine = torch.sqrt(_3)
    cos_m = self.cos_m
    _4 = torch.mul(cosine, cos_m)
    sin_m = self.sin_m
    phi = torch.sub(_4, torch.mul(sine, sin_m))
    easy_margin = self.easy_margin
    if easy_margin:
      phi1 = torch.where(torch.gt(cosine, 0), phi, cosine)
      phi0 = phi1
    else:
      th = self.th
      _5 = torch.gt(cosine, th)
      mmm = self.mmm
      phi2 = torch.where(_5, phi, torch.sub(cosine, mmm))
      phi0 = phi2
    one_hot = torch.new_zeros(input, torch.size(cosine))
    _6 = torch.to(torch.view(label, [-1, 1]), 4)
    _7 = torch.scatter_(one_hot, 1, _6, 1)
    _8 = torch.mul(one_hot, phi0)
    _9 = torch.mul(torch.add(torch.neg(one_hot), 1.), cosine)
    output = torch.add(_8, _9)
    scale = self.scale
    return torch.mul_(output, scale)
