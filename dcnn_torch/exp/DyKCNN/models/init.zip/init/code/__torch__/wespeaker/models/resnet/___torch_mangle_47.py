class BasicBlock2(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  is_dynamic : bool
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_41.Conv2d
  bn1 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_42.BatchNorm2d
  conv2 : __torch__.torch.nn.modules.container.___torch_mangle_44.Sequential
  shortcut : __torch__.torch.nn.modules.container.___torch_mangle_46.Sequential
  def forward(self: __torch__.wespeaker.models.resnet.___torch_mangle_47.BasicBlock2,
    x: Tensor) -> Tensor:
    bn1 = self.bn1
    conv1 = self.conv1
    _0 = (bn1).forward((conv1).forward(x, ), )
    out = __torch__.torch.nn.functional.relu(_0, False, )
    conv2 = self.conv2
    out0 = (conv2).forward(out, )
    shortcut = self.shortcut
    out1 = torch.add_(out0, (shortcut).forward(x, ))
    out2 = __torch__.torch.nn.functional.relu(out1, False, )
    return out2
