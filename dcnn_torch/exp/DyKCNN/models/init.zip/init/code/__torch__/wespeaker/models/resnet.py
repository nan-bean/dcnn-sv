class ResNet2(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  in_planes : int
  feat_dim : int
  embed_dim : int
  stats_dim : int
  two_emb_layer : bool
  pool_out_dim : int
  conv1 : __torch__.torch.nn.modules.conv.Conv2d
  bn1 : __torch__.torch.nn.modules.batchnorm.BatchNorm2d
  layer1 : __torch__.torch.nn.modules.container.___torch_mangle_8.Sequential
  layer2 : __torch__.torch.nn.modules.container.___torch_mangle_25.Sequential
  layer3 : __torch__.torch.nn.modules.container.___torch_mangle_40.Sequential
  layer4 : __torch__.torch.nn.modules.container.___torch_mangle_49.Sequential
  pool : __torch__.wespeaker.models.pooling_layers.TSTP
  seg_1 : __torch__.torch.nn.modules.linear.Linear
  seg_bn_1 : __torch__.torch.nn.modules.linear.Identity
  seg_2 : __torch__.torch.nn.modules.linear.Identity
  projection : __torch__.wespeaker.models.projections.ArcMarginProduct
  def forward(self: __torch__.wespeaker.models.resnet.ResNet2,
    x: Tensor) -> Tuple[Tensor, Tensor]:
    x0 = torch.permute(x, [0, 2, 1])
    x1 = torch.unsqueeze_(x0, 1)
    bn1 = self.bn1
    conv1 = self.conv1
    _0 = (bn1).forward((conv1).forward(x1, ), )
    out = __torch__.torch.nn.functional.relu(_0, False, )
    layer1 = self.layer1
    out0 = (layer1).forward(out, )
    layer2 = self.layer2
    out1 = (layer2).forward(out0, )
    layer3 = self.layer3
    out2 = (layer3).forward(out1, )
    layer4 = self.layer4
    out3 = (layer4).forward(out2, )
    pool = self.pool
    stats = (pool).forward(out3, )
    seg_1 = self.seg_1
    embed_a = (seg_1).forward(stats, )
    two_emb_layer = self.two_emb_layer
    if two_emb_layer:
      out4 = __torch__.torch.nn.functional.relu(embed_a, False, )
      seg_bn_1 = self.seg_bn_1
      out5 = (seg_bn_1).forward(out4, )
      seg_2 = self.seg_2
      embed_b = (seg_2).forward(out5, )
      _1 = (embed_a, embed_b)
    else:
      _1 = (torch.tensor(0.), embed_a)
    return _1
class BasicBlock2(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  is_dynamic : bool
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv2d
  bn1 : __torch__.torch.nn.modules.batchnorm.BatchNorm2d
  conv2 : __torch__.wespeaker.models.resnet.GDCNN
  shortcut : __torch__.torch.nn.modules.container.Sequential
  def forward(self: __torch__.wespeaker.models.resnet.BasicBlock2,
    x: Tensor) -> Tensor:
    bn1 = self.bn1
    conv1 = self.conv1
    _2 = (bn1).forward((conv1).forward(x, ), )
    out = __torch__.torch.nn.functional.relu(_2, False, )
    conv2 = self.conv2
    out6 = (conv2).forward(out, )
    shortcut = self.shortcut
    out7 = torch.add_(out6, (shortcut).forward(x, ))
    out8 = __torch__.torch.nn.functional.relu(out7, False, )
    return out8
class GDCNN(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  mws_weights : Tensor
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv2d
  bn1 : __torch__.torch.nn.modules.batchnorm.BatchNorm2d
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv2d
  bn2 : __torch__.torch.nn.modules.batchnorm.BatchNorm2d
  conv_reduc : __torch__.torch.nn.modules.conv.___torch_mangle_1.Conv2d
  bn_reduc : __torch__.torch.nn.modules.batchnorm.___torch_mangle_2.BatchNorm2d
  sbsa1 : __torch__.wespeaker.models.resnet.SBSA
  sbsa2 : __torch__.wespeaker.models.resnet.SBSA
  conv_sbsa_exc : __torch__.torch.nn.modules.conv.___torch_mangle_4.Conv2d
  bn_sbsa : __torch__.torch.nn.modules.batchnorm.BatchNorm2d
  mws : __torch__.torch.nn.modules.conv.___torch_mangle_5.Conv2d
  conv_mws_exc : __torch__.torch.nn.modules.conv.___torch_mangle_6.Conv2d
  bn_mws : __torch__.torch.nn.modules.batchnorm.BatchNorm2d
  conv_sks : __torch__.torch.nn.modules.conv.___torch_mangle_7.Conv2d
  bn_sks : __torch__.torch.nn.modules.batchnorm.BatchNorm2d
  def forward(self: __torch__.wespeaker.models.resnet.GDCNN,
    x: Tensor) -> Tensor:
    bn_reduc = self.bn_reduc
    conv_reduc = self.conv_reduc
    _3 = (bn_reduc).forward((conv_reduc).forward(x, ), )
    acve_r = __torch__.torch.nn.functional.relu(_3, False, )
    sbsa1 = self.sbsa1
    _4 = (sbsa1).forward(acve_r, )
    sbsa2 = self.sbsa2
    sbsa = torch.cat([_4, (sbsa2).forward(acve_r, )], 1)
    bn_sbsa = self.bn_sbsa
    conv_sbsa_exc = self.conv_sbsa_exc
    _5 = (bn_sbsa).forward((conv_sbsa_exc).forward(sbsa, ), )
    sbsa0 = __torch__.torch.nn.functional.relu(_5, False, )
    mws = self.mws
    mws0 = (mws).forward(acve_r, )
    bn_mws = self.bn_mws
    conv_mws_exc = self.conv_mws_exc
    _6 = (bn_mws).forward((conv_mws_exc).forward(mws0, ), )
    mws1 = __torch__.torch.nn.functional.relu(_6, False, )
    acve = torch.add(torch.add(x, sbsa0), mws1)
    bn_sks = self.bn_sks
    conv_sks = self.conv_sks
    _7 = (bn_sks).forward((conv_sks).forward(acve, ), )
    sks = torch.add(torch.tanh(_7), 1.)
    bn1 = self.bn1
    conv1 = self.conv1
    _8 = (conv1).forward(torch.mul(sks, x), )
    out1 = (bn1).forward(_8, )
    bn2 = self.bn2
    conv2 = self.conv2
    _9 = torch.mul(torch.add(torch.neg(sks), 2.), x)
    out2 = (bn2).forward((conv2).forward(_9, ), )
    return torch.add(out1, out2)
class SBSA(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  ln_q : __torch__.torch.nn.modules.conv.___torch_mangle_3.Conv2d
  ln_k : __torch__.torch.nn.modules.conv.___torch_mangle_3.Conv2d
  ln_v : __torch__.torch.nn.modules.conv.___torch_mangle_3.Conv2d
  def forward(self: __torch__.wespeaker.models.resnet.SBSA,
    x: Tensor) -> Tensor:
    n_batch = torch.size(x, 0)
    n_planes = torch.size(x, 1)
    n_freq = torch.size(x, 2)
    n_frame = torch.size(x, 3)
    ln_q = self.ln_q
    _10 = torch.permute((ln_q).forward(x, ), [0, 3, 2, 1])
    _11 = torch.contiguous(_10)
    _12 = [n_batch, n_frame, torch.mul(n_freq, n_planes)]
    q = torch.view(_11, _12)
    ln_k = self.ln_k
    _13 = torch.permute((ln_k).forward(x, ), [0, 3, 2, 1])
    _14 = torch.contiguous(_13)
    _15 = [n_batch, n_frame, torch.mul(n_freq, n_planes)]
    k = torch.view(_14, _15)
    ln_v = self.ln_v
    _16 = torch.permute((ln_v).forward(x, ), [0, 3, 2, 1])
    _17 = torch.contiguous(_16)
    _18 = [n_batch, n_frame, torch.mul(n_freq, n_planes)]
    v = torch.view(_17, _18)
    _19 = torch.matmul(q, torch.transpose(k, -2, -1))
    _20 = torch.sqrt(torch.mul(n_freq, n_planes))
    scores = torch.div(_19, _20)
    attn = torch.softmax(scores, -1)
    _21 = torch.matmul(attn, v)
    _22 = [n_batch, n_frame, n_freq, n_planes]
    _23 = torch.permute(torch.view(_21, _22), [0, 3, 2, 1])
    return torch.contiguous(_23)
