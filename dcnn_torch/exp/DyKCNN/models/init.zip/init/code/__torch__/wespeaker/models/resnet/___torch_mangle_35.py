class GDCNN(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  mws_weights : Tensor
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_28.Conv2d
  bn1 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_27.BatchNorm2d
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_28.Conv2d
  bn2 : __torch__.torch.nn.modules.batchnorm.___torch_mangle_27.BatchNorm2d
  conv_reduc : __torch__.torch.nn.modules.conv.___torch_mangle_29.Conv2d
  bn_reduc : __torch__.torch.nn.modules.batchnorm.BatchNorm2d
  sbsa1 : __torch__.wespeaker.models.resnet.___torch_mangle_30.SBSA
  sbsa2 : __torch__.wespeaker.models.resnet.___torch_mangle_30.SBSA
  conv_sbsa_exc : __torch__.torch.nn.modules.conv.___torch_mangle_31.Conv2d
  bn_sbsa : __torch__.torch.nn.modules.batchnorm.___torch_mangle_27.BatchNorm2d
  mws : __torch__.torch.nn.modules.conv.___torch_mangle_32.Conv2d
  conv_mws_exc : __torch__.torch.nn.modules.conv.___torch_mangle_33.Conv2d
  bn_mws : __torch__.torch.nn.modules.batchnorm.___torch_mangle_27.BatchNorm2d
  conv_sks : __torch__.torch.nn.modules.conv.___torch_mangle_34.Conv2d
  bn_sks : __torch__.torch.nn.modules.batchnorm.___torch_mangle_27.BatchNorm2d
  def forward(self: __torch__.wespeaker.models.resnet.___torch_mangle_35.GDCNN,
    x: Tensor) -> Tensor:
    bn_reduc = self.bn_reduc
    conv_reduc = self.conv_reduc
    _0 = (bn_reduc).forward((conv_reduc).forward(x, ), )
    acve_r = __torch__.torch.nn.functional.relu(_0, False, )
    sbsa1 = self.sbsa1
    _1 = (sbsa1).forward(acve_r, )
    sbsa2 = self.sbsa2
    sbsa = torch.cat([_1, (sbsa2).forward(acve_r, )], 1)
    bn_sbsa = self.bn_sbsa
    conv_sbsa_exc = self.conv_sbsa_exc
    _2 = (bn_sbsa).forward((conv_sbsa_exc).forward(sbsa, ), )
    sbsa0 = __torch__.torch.nn.functional.relu(_2, False, )
    mws = self.mws
    mws0 = (mws).forward(acve_r, )
    bn_mws = self.bn_mws
    conv_mws_exc = self.conv_mws_exc
    _3 = (bn_mws).forward((conv_mws_exc).forward(mws0, ), )
    mws1 = __torch__.torch.nn.functional.relu(_3, False, )
    acve = torch.add(torch.add(x, sbsa0), mws1)
    bn_sks = self.bn_sks
    conv_sks = self.conv_sks
    _4 = (bn_sks).forward((conv_sks).forward(acve, ), )
    sks = torch.add(torch.tanh(_4), 1.)
    bn1 = self.bn1
    conv1 = self.conv1
    _5 = (conv1).forward(torch.mul(sks, x), )
    out1 = (bn1).forward(_5, )
    bn2 = self.bn2
    conv2 = self.conv2
    _6 = torch.mul(torch.add(torch.neg(sks), 2.), x)
    out2 = (bn2).forward((conv2).forward(_6, ), )
    return torch.add(out1, out2)
